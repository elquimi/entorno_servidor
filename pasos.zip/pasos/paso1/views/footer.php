<footer>
  <p class="small">Estructura de este paso:</p>
  <pre>
paso1/
  db.php
  index.php
  assets/
    js/
    css/
    images/   
  views/
    header.php
    footer.php
  README.md
  </pre>
  <p class="small">Recuerda: en Paso 2 moveremos la lógica de BD al Modelo.</p>
</footer>
</body>
</html>