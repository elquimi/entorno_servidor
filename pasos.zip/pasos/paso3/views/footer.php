<?php
// paso3/views/footer.php
?>
</main>
<hr>
<footer>
 <p class="small">Estructura de este paso:</p>
 <pre>
paso3/
 db.php
 models/
 ClienteModel.php
 controllers/
 ClienteController.php
 views/
 header.php
 footer.php
 clientes/
 list.php
 form.php
 index.php
 README.md
 </pre>
 <p class="small">Siguiente: Paso 4 → Front controller / Router.</p>
</footer>
</body>
</html>